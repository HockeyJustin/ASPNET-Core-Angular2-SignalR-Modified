﻿using System;

namespace ASPNETCoreAngular2Demo.ViewModels
{
    public class FoodItemViewModel
    {
        public int Id { get; set; }
        public string ItemName { get; set; }
        public DateTime Created { get; set; }
    }
}
