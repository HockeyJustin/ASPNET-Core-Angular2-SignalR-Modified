﻿namespace ASPNETCoreAngular2Demo.Services
{
    public class TimerServiceConfiguration
    {
        public int DueTime { get; set; }

        public int Period { get; set; }
    }
}
