﻿import { Component } from '@angular/core';


@Component({
	selector: 'signaturepage',	
	templateUrl: './signaturepage.component.html'
})

export class SignaturePageComponent {

	constructor() {
	}

}

