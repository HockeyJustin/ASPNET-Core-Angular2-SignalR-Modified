﻿import { Component, NgZone } from '@angular/core';
import { SignalRService } from '../../services/signalRService';

@Component({
	selector: 'signature',
	templateUrl: './signature.component.html'
})


export class SignatureComponent {

	public registrationDeskId: string;
	public canSendMessage: Boolean;
	private isRegistered: Boolean;
	private clientStaticUniqueIdentifier: any;

	constructor(private _signalRService: SignalRService, private _ngZone: NgZone) {
		this.subscribeToEvents();
		this.isRegistered = false;
		this.clientStaticUniqueIdentifier = Guid.newGuid();
		this.canSendMessage = _signalRService.connectionExists;
	}


	public sendRegistration() {
		if (this.canSendMessage) {
			this._signalRService.sendRegistrationId(this.clientStaticUniqueIdentifier, this.registrationDeskId);
		}
	}


	private subscribeToEvents(): void {
		this._signalRService.connectionEstablished.subscribe(() => {
			this.canSendMessage = true;
		});

		this._signalRService.successFailMessage.subscribe((message: string) => {
			this._ngZone.run(() => {
				if (message === 'success') {
					this.isRegistered = true;
				} else {
					this.isRegistered = false;
				}
			});
		});
	}

}

class Guid {
	static newGuid() {
		return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
			var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
			return v.toString(16);
		});
	}
}