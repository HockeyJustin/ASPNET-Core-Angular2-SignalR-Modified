
export class FoodItem {
    public id: number;
    public itemName: string;
    public created: Date;
}

