﻿export class RegDesk {
	// the name the user puts in
	public RegDeskUserName: string;

	// the id created by signalR on connect.
	public SignalRClientId: string;

	// An ID generated on the client that, unlike the SignalR client ID, 
	// will not change on reconnect.
	public StaticClientGuid: any;

	constructor(regDeskUserName: string, signalRClientId: string, staticClientGuid: any) {
		this.RegDeskUserName = regDeskUserName;
		this.SignalRClientId = signalRClientId;
		this.StaticClientGuid = staticClientGuid;
	}

}