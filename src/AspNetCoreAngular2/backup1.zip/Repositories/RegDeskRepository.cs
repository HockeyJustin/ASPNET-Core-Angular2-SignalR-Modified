﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPNETCoreAngular2Demo.Repositories
{
	public interface IRegDeskRepository
	{
		//void AddRegDesk(Guid)
	}


    public class RegDeskRepository
    {
    }
}
