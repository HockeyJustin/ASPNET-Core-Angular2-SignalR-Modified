﻿using ASPNETCoreAngular2Demo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPNETCoreAngular2Demo.Repositories
{
	public class RegDeskSignatureRepository
	{
		List<RegDeskSignature> _regDesks = new List<RegDeskSignature>();

		public void Add(RegDeskSignature regDesk)
		{
			var currentListing = _regDesks.FirstOrDefault(i => i.RegDeskUserName.ToLower() == regDesk.RegDeskUserName.ToLower());

			if (currentListing != null)
			{
				currentListing = regDesk;
			}
			else
			{
				_regDesks.Add(regDesk);
			}

		}

		public RegDeskSignature Get(string regDeskUserName)
		{
			return _regDesks.FirstOrDefault(i => i.RegDeskUserName.ToLower() == regDeskUserName.ToLower());
		}


		private static RegDeskSignatureRepository _instance;
		public static RegDeskSignatureRepository Instance()
		{
			if (_instance == null)
			{
				_instance = new RegDeskSignatureRepository();
			}
			return _instance;
		}


	}
}
