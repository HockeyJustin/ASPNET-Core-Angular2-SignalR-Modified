﻿using ASPNETCoreAngular2Demo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPNETCoreAngular2Demo.Repositories
{

	public class RegDeskRepository
	{
		List<RegDesk> _regDesks = new List<RegDesk>();

		public void Add(RegDesk regDesk)
		{
			_regDesks.Add(regDesk);
		}

		public RegDesk Get(string regDeskUserName)
		{
			return _regDesks.FirstOrDefault(i => i.RegDeskUserName.ToLower() == regDeskUserName.ToLower());
		}


		private static RegDeskRepository _instance;
		public static RegDeskRepository Instance()
		{
			if (_instance == null)
			{
				_instance = new RegDeskRepository();
			}
			return _instance;
		}

	}
}
