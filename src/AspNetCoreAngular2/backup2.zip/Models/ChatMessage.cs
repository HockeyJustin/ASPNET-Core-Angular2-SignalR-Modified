using System;

namespace ASPNETCoreAngular2Demo.Models
{
    public class ChatMessage
    {
        public string Message { get; set; }
        public DateTime Sent { get; set; }
    }
}
