﻿import { RegDeskBase } from '../models/RegDeskBase';

export class RegDesk extends RegDeskBase {
	// the name the user puts in
	public RegDeskUserName: string;

	constructor(regDeskUserName: string, signalRClientId: string, staticClientGuid: any) {
		super(signalRClientId, staticClientGuid);

		this.RegDeskUserName = regDeskUserName;		
	}

}