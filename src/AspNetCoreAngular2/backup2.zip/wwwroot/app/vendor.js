"use strict";
// Angular
require('@angular/platform-browser');
require('@angular/platform-browser-dynamic');
require('@angular/core');
require('@angular/common');
require('@angular/http');
require('@angular/router');
// RxJS
require('rxjs');
// Other libraries.
require('jquery/src/jquery');
require('bootstrap/dist/js/bootstrap');
//# sourceMappingURL=vendor.js.map