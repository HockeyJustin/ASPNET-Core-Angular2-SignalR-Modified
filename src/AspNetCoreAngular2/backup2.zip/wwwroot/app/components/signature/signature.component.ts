﻿import { Component, NgZone } from '@angular/core';
import { SignalRService } from '../../services/signalRService';
import { RegDesk } from '../../models/RegDesk';
import { RegDeskSignature } from '../../models/RegDeskSignature';
import { Guid } from '../../models/Guid';

@Component({
	selector: 'signature',
	templateUrl: './signature.component.html'
})


export class SignatureComponent {

	public regDesk: RegDesk;
	public canSendMessage: Boolean;
	private isRegistered: Boolean;
	private isSignatureCaptureStarted: Boolean;
	public signature: string;


	constructor(private _signalRService: SignalRService, private _ngZone: NgZone) {
		this.subscribeToEvents();
		this.isRegistered = false;
		this.regDesk = new RegDesk('', '', Guid.newGuid());
		this.canSendMessage = _signalRService.connectionExists;
	}


	public sendRegistration() {
		if (this.canSendMessage) {
			this._signalRService.sendRegistrationId(this.regDesk);
		}
	}

	public saveSignature() {
		if (this.canSendMessage && this.isSignatureCaptureStarted) {
			var regDeskSig = new RegDeskSignature(this.regDesk.RegDeskUserName, this.regDesk.SignalRClientId, this.regDesk.StaticClientGuid, this.signature);
			this._signalRService.saveSignature(regDeskSig);
		}
	}


	private subscribeToEvents(): void {
		this._signalRService.connectionEstablished.subscribe(() => {
			this.canSendMessage = true;
			this.regDesk.SignalRClientId = this._signalRService.connectionId;
		});

		this._signalRService.successFailMessage.subscribe((message: string) => {
			this._ngZone.run(() => {
				if (message === 'success') {
					this.isRegistered = true;
				} else {
					this.isRegistered = false;
				}
			});
		});

		this._signalRService.saveSignatureSuccessOrFailMessage.subscribe((message: string) => {
			this._ngZone.run(() => {
				if (message === 'success') {
					this.isSignatureCaptureStarted = false;
					this.signature = '';
				} else {
					this.signature = 'error!';
				}
			});
		})


		this._signalRService.startSignatureCaptureMessage.subscribe((message: string) => {
			this._ngZone.run(() => {
				this.isSignatureCaptureStarted = true;
			});
		})
	}

}

