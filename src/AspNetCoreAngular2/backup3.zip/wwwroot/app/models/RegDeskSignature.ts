﻿import { RegDesk } from '../models/RegDesk';

export class RegDeskSignature extends RegDesk {

	public Signature: string;


	constructor(regDeskUserName: string, signalRClientId: string, staticClientGuid: any, signature: string) {
		super(regDeskUserName, signalRClientId, staticClientGuid);

		this.Signature = signature;
	}

}