"use strict";
exports.CONFIGURATION = {
    baseUrls: {
        server: 'http://localhost:5000/',
        apiUrl: 'api/',
    },
};
//# sourceMappingURL=app.constants.js.map