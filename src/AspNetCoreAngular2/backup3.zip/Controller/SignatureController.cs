﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.AspNetCore.SignalR.Infrastructure;
using ASPNETCoreAngular2Demo.Services;
using ASPNETCoreAngular2Demo.Hubs;
using ASPNETCoreAngular2Demo.Repositories;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace ASPNETCoreAngular2Demo.Controller
{
	[Route("api/[controller]")]
	public class SignatureController : Microsoft.AspNetCore.Mvc.Controller
	{
		private readonly IHubContext _coolMessageHubContext;

		public SignatureController(IConnectionManager connectionManager, ITimerService timerService)
		{			
			_coolMessageHubContext = connectionManager.GetHubContext<CoolMessagesHub>();
			timerService.TimerElapsed += _timerService_TimerElapsed;
		}
		// GET: /<controller>/

		[HttpGet]
		public IActionResult GetLastSignature(string regDeskUserName)
        {
			if (String.IsNullOrWhiteSpace(regDeskUserName))
			{
				return BadRequest();
			}

			var matchingSignature = RegDeskSignatureRepository.Instance().Get(regDeskUserName);

			if (matchingSignature != null)
			{
				return Json(matchingSignature);
			}
			else
			{
				return Content("No signature yet.");
			}
		}


		[HttpPost]
		public IActionResult StartSignature(string regDeskUserName)
		{

			if (String.IsNullOrWhiteSpace(regDeskUserName))
			{
				return BadRequest();
			}

			var matchingDesk = RegDeskRepository.Instance().Get(regDeskUserName);

			if (matchingDesk != null)
			{
				_coolMessageHubContext.Clients.Client(matchingDesk.SignalRClientId)
					.StartSignatureCapture("GO!");
				return Content("OK");
			}
			else
			{
				return Content("No reg desk with that name. (username usually something like 'Reg Desk 1')");
			}

		}



		private void _timerService_TimerElapsed(object sender, EventArgs e)
		{
			TimerEventArgs eventsArgs = e as TimerEventArgs;
			_coolMessageHubContext.Clients.All.newCpuValue(eventsArgs.Value);
		}

	}
}
